# php-oo-mvc-juin2
Projet PHP Orienté Objet en MVC avec administration - Niveau 2 - 2 tables - one to many
### To researche the order of creating code in project, use ctrl+shift+F (PhpStorm) with "aaa"

aaa001, aaa002, etc ...
# Asset

Un asset est défini comme une ressource basique devant être affichée dans un navigateur web - ce dossier doit rester publique.
# aaa099
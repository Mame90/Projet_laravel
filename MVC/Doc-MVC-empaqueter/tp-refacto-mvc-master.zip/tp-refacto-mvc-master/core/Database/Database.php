<?php
namespace Core\Database; // Initialise database.php dans le fichier 'app' contenant toutes les classes

/**
* Connexion a la base de donnée
*/
class Database
{

}
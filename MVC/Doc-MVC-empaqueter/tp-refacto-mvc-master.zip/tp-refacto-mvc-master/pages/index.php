<div class="row">
    <div class="col-md-12 alert alert-info">
        <strong>Informations:</strong> il n'y a rien à voir ici, connectez vous en administrateur pour accéder à du contenu.
    </div>
</div>
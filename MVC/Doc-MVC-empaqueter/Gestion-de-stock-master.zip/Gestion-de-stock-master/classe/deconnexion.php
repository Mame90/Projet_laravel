<?php

session_start();
session_destroy();

header('location:../acceuille.php');

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Document sans titre</title>
</head>

<body>

</body>
</html>

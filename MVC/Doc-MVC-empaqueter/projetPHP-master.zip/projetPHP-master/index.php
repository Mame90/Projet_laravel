<?php

require 'controleur/routeur/Routeur.php';
require 'vue/classe/Vue.php';

$routeur = new Routeur();
$routeur->routerRequete();

<?php
  $tableau = ["diapo", "mere binta", "mm toure", "aladji zono", "aladji libs"];
 

?>
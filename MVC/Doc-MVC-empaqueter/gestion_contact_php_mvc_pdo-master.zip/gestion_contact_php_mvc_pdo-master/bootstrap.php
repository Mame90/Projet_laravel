<?php 
namespace App\bootstrap;
class bootstrap{

    public function const() {
        define('BASE_URL','http://localhost/gestion_contact');
    }

}

?>